﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    /// <summary>
    /// Jedan element genericke liste.
    /// </summary>
    /// <typeparam name="T"> Genericki tip. </typeparam>
    public class Element<T>
    {
        public T vrednost;         // Vrednost
        public Element<T> sledeci; // Pokazivac na sledeci

        public Element(T v)
        {
            vrednost = v;
        }
    }
}
