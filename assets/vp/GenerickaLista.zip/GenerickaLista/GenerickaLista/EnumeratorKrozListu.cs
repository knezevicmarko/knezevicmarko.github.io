﻿using System;
using System.Collections.Generic;

namespace GenerickaLista
{
    public class EnumeratorKrozListu<T> : IEnumerator<T> where T : class, IUporediv<T>
    {
        Lista<T> lista;
        Element<T> trenutni = null;

        public EnumeratorKrozListu(Lista<T> lista)
        {
            this.lista = lista;
        }

        public T Current
        {
            get { return trenutni.vrednost; }
        }

        public void Dispose()
        {

        }

        object System.Collections.IEnumerator.Current
        {
            get { throw new NotImplementedException(); }
        }

        public bool MoveNext()
        {
            if (trenutni == null)
            {
                trenutni = lista.glava;
                return true;
            }
            else
            {
                if (trenutni.sledeci != null)
                {
                    trenutni = trenutni.sledeci;
                    return true;
                }
                else
                    return false;

            }
        }

        public void Reset()
        {
            trenutni = null;
        }
    }
}