﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    /// <summary>
    /// Genericki interfejs za uporedjivanje dva ganericka tipa.
    /// </summary>
    /// <typeparam name="T"> Genericki tip. </typeparam>
    public interface IUporediv<T>
    {
        int Uporedi(T vrednost);
    }
}
