﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    public class Lista<T> : IEnumerable<T> where T : class, IUporediv<T>
    {

        public Element<T> glava = null;

        public Lista(T vrednost)
        {
            glava = new Element<T>(vrednost);
        }

        /// <summary>
        /// Indekser koji moze da postavi ili dohvati vrednost odgovarajuceg elementa.
        /// </summary>
        /// <param name="indeks"> Indeks elementa u listi. </param>
        /// <returns> Vrednost genericke promenljive koje se nalazi na "indeks" poziciji. </returns>
        public T this[int indeks]
        {
            get
            {
                Element<T> tmp = glava;

                for (int i = 0; i < indeks; i++)
                {
                    tmp = tmp.sledeci;
                }

                return tmp.vrednost;
            }

            set
            {
                Element<T> tmp = glava;

                for (int i = 0; i < indeks; i++)
                {
                    tmp = tmp.sledeci;
                }

                tmp.vrednost = value;
            }
        }

        /// <summary>
        /// Svojstvo koje vraca broj elemenata koji se nalaze u listi.
        /// </summary>
        public long BrojElemenata
        {
            get
            {
                int brojElemenata = 1;

                Element<T> tmp = glava;
                while (tmp.sledeci != null)
                {
                    tmp = tmp.sledeci;
                    brojElemenata++;
                }

                return brojElemenata;
            }
        }

        /// <summary>
        /// Metod koji sortira elemente u listi
        /// Koristi se selection sort kao primer koriscenja indeksera.
        /// </summary>
        public void Sortiraj()
        {
            for (int i = 0; i < BrojElemenata; i++)
            {
                for (int j = i + 1; j < BrojElemenata; j++)
                {
                    T v1 = this[i];
                    T v2 = this[j];

                    if (v1.Uporedi(v2) == -1)
                    {
                        this[i] = v2;
                        this[j] = v1;
                    }
                }

            }
        }

        public void Add(T novaVrednost)
        {
            Element<T> tmp = glava;

            while (tmp.sledeci != null)
            {
                tmp = tmp.sledeci;
            }

            tmp.sledeci = new Element<T>(novaVrednost);
        }

        public IEnumerator<T> GetEnumerator()
        {
            return new EnumeratorKrozListu<T>(this);
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
