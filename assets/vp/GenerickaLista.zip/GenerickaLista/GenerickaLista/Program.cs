﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    class Program
    {
        static void Main(string[] args)
        {
            // Primer sa radnicima

            Lista<Radnik> radnici = new Lista<Radnik>(new Radnik("Cika Zika", 35000));
            radnici.Add(new Radnik("Torbica", 55000));
            radnici.Add(new Radnik("Cvarkov Djordje", 100000));
            radnici.Add(new Radnik("Boskic", 50000));
            radnici.Add(new Radnik("Visekruna", 150000));

            Console.WriteLine("");
            Console.WriteLine("Radnici: ");
            Console.WriteLine("");

            foreach (var radnik in radnici)
            {
                Console.WriteLine(radnik);
            }

            Console.WriteLine();
            Console.WriteLine("----------------------");
            Console.WriteLine();
            Console.WriteLine("Sortirani radnici:");
            Console.WriteLine();

            radnici.Sortiraj();

            foreach (var radnik in radnici)
            {
                Console.WriteLine(radnik);
            }

            Console.WriteLine();
            Console.WriteLine("*******************************");

            // Primer sa Studentima

            Lista<Student> studenti = new Lista<Student>(new Student("Student", " Cika Zika", 6.8));
            studenti.Add(new Student("Student  Torbica", "Dragan", 7.8));
            studenti.Add(new Student("Student", "Cvarkov Djordje", 9.92));
            studenti.Add(new Student("Student", "Boskic", 6.2));
            studenti.Add(new Student("Student", "Visekruna", 9.9));

            Console.WriteLine("");
            Console.WriteLine("Studenti: ");
            Console.WriteLine("");

            foreach (var student in studenti)
            {
                Console.WriteLine(student);
            }

            Console.WriteLine();
            Console.WriteLine("----------------------");
            Console.WriteLine();
            Console.WriteLine("Sortirani studenti:");
            Console.WriteLine();

            studenti.Sortiraj();

            foreach (var student in studenti)
            {
                Console.WriteLine(student);
            }
        }
    }
}
