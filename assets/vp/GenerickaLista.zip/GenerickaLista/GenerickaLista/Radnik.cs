﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    /// <summary>
    /// Primer klase koja moze da se smesti u Lista<T>.
    /// </summary>
    public class Radnik : IUporediv<Radnik>
    {
        public string ime;
        public double plata;

        public Radnik(string ime, double plata)
        {
            this.ime = ime;
            this.plata = plata;
        }

        public int Uporedi(Radnik radnik)
        {
            if (plata > radnik.plata)
                return 1;
            else if (plata == radnik.plata)
                return 0;
            else
                return -1;
        }

        public override string ToString()
        {
            return ime + ". Plata : " + plata;
        }
    }
}
