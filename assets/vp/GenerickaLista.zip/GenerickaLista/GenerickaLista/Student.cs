﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerickaLista
{
    /// <summary>
    /// Primer klase koja moze da se smesti u Lista<T>.
    /// </summary>
    public class Student : IUporediv<Student>
    {
        public string ime;
        public string prezime;
        public double prosek;

        public Student(string ime, string prezime, double prosek)
        {
            this.ime = ime;
            this.prezime = prezime;
            this.prosek = prosek;
        }

        public int Uporedi(Student student)
        {
            if (prosek > student.prosek)
                return 1;
            else if (prosek == student.prosek)
                return 0;
            else
                return -1;
        }

        public override string ToString()
        {
            return ime + " " + prezime + ". Prosek : " + prosek;
        }
    }
}
