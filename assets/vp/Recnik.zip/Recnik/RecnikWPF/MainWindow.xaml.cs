﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;

namespace RecnikWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Recnik<string, Student> matematika;
        Recnik<string, Student> informatika;

        public MainWindow()
        {
            InitializeComponent();

            matematika  = new Recnik<string, Student>();
            informatika = new Recnik<string, Student>();

            matematika.PromenaBrojaElemenata += new ObjavaBrojaElemenata(matematika_PromeneBrojaElemenata);
            informatika.PromenaBrojaElemenata += new ObjavaBrojaElemenata(informatika_PromeneBrojaElemenata);
        }

        void informatika_PromeneBrojaElemenata(int brojElemenata)
        {
            label_BrojStudenataNaInformatici.Content = brojElemenata + "";
        }

        void matematika_PromeneBrojaElemenata(int brojElemenata)
        {
            label_BrojStudenataNaMatematici.Content = brojElemenata + "";
        }

        private void button_DodajIzFajla_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == true)
            {
                StreamReader sr = new StreamReader(ofd.FileName);

                string[] vrednosti;
                string linija;

                while (!sr.EndOfStream)
                {
                    linija = sr.ReadLine();

                    vrednosti = linija.Split(',');

                    Student s = new Student(vrednosti[0], vrednosti[1], int.Parse(vrednosti[2]), float.Parse(vrednosti[3]));

                    if (vrednosti[4] == "matematika")
                    {
                        matematika[vrednosti[0]] = s;
                    }
                    else
                    {
                        informatika[vrednosti[0]] = s;
                    }
                }

                listBox_Matematika.Items.Clear();

                foreach (var s in matematika)
                {
                    listBox_Matematika.Items.Add(s.vrednost);
                }

                listBox_Informatika.Items.Clear();

                foreach (var s in informatika)
                {
                    listBox_Informatika.Items.Add(s.vrednost);
                }

            }
        }

        private void button_Dodaj_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student s = new Student(textBox_brojIndeksa.Text, textBox_ImeIPrezime.Text, int.Parse(textBox_BrojPolozenihIspita.Text), float.Parse(textBox_Prosek.Text));

                if (radioButton_Matematika.IsChecked.Value == true)
                {

                    matematika[textBox_brojIndeksa.Text] = s;

                    listBox_Matematika.Items.Clear();

                    foreach (var ss in matematika)
                    {
                        listBox_Matematika.Items.Add(ss.vrednost);
                    }

                }
                else
                {
                    informatika[textBox_brojIndeksa.Text] = s;

                    listBox_Informatika.Items.Clear();

                    foreach (var ss in informatika)
                    {
                        listBox_Informatika.Items.Add(ss.vrednost);
                    }


                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void buttonPrikaziStudentaMatematike_Click(object sender, RoutedEventArgs e)
        {
            string indeks = textBox_IndeksMatematika.Text;
            Student s = matematika[indeks];

            if (s != null)
                textBlockPrikazMatematika.Text = s.ToString();
            else 
                textBlockPrikazMatematika.Text = "Student sa indeksom " + indeks + " ne postoji u listi";
        }

        private void buttonPrikaziStudentaInformatike_Click(object sender, RoutedEventArgs e)
        {
            string indeks = textBox_IndeksInformatika.Text;
            Student s = informatika[indeks];

            if (s != null)
                textBlockPrikazInformatika.Text = s.ToString();
            else 
                textBlockPrikazInformatika.Text = "Student sa indeksom " + indeks + " ne postoji u listi";
        }

        private void comboBox_IzborOpcijePrikaza_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            listBoxRezultat.Items.Clear();

            IEnumerable<Par<string, Student>> rezultat = null;

            switch (comboBox_IzborOpcijePrikaza.SelectedIndex)
            {
                case 0:
                    rezultat = matematika + informatika;
                break;
                case 1:
                    rezultat = informatika.Filtriraj(x => x.vrednost.prosek > 7.5 && x.vrednost.brojPolozenihIspita > 10);
                break;
                case 2:
                    rezultat = matematika.Filtriraj(x => x.vrednost.prosek > 7.5 && int.Parse(x.vrednost.indeks.Split('/')[1]) > 2012);
                break;
                case 3:
                    List<string> indeksi = matematika;

                    foreach (var item in indeksi)
                    {
                        listBoxRezultat.Items.Add(item);
                    }

                    return;

                break;
                default:
                    break;
            }

            foreach (var item in rezultat)
	        {
		        listBoxRezultat.Items.Add(item.vrednost);
	        }
        }

    }

}
