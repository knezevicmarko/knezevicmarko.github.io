﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RecnikWPF
{

    public class Par<Kljuc, Vrednost>
        where Kljuc : class, IEquatable<Kljuc>
        where Vrednost : class, IEquatable<Vrednost>
    {
        public Kljuc kljuc;
        public Vrednost vrednost;

        public Par(Kljuc kljuc, Vrednost vrednost)
        {
            this.kljuc = kljuc;
            this.vrednost = vrednost;
        }

        public override string ToString()
        {
            return "Kljuc: " + kljuc + ", vrednost: " + vrednost;
        }
    }
}
