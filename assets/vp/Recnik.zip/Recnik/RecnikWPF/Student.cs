﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RecnikWPF
{
    public class Student : IEquatable<Student>
    {
        public string indeks;
        public string ime;
        public int brojPolozenihIspita;
        public float prosek;

        public Student(string indeks, string ime, int brojPolozenihIspita, float prosek)
        {
            this.indeks = indeks;
            this.ime = ime;
            this.brojPolozenihIspita = brojPolozenihIspita;
            this.prosek = prosek;
        }

        public override string ToString()
        {
            return "" + indeks + ", " + ime + ", " + brojPolozenihIspita + ", " + prosek;
        }


        public bool Equals(Student other)
        {
            if (indeks == other.indeks)
                return true;
            else
                return false;
        }
    }

}
